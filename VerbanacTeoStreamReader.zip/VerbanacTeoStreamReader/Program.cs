﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VerbanacTeoStreamReader
{

    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader(@"C:\Users\Ucenik\Documents\more.txt");
            // Čitamo datoteku liniju po liniju
            while (!sr.EndOfStream)
            {
                Console.WriteLine(sr.ReadLine());
            }
            // Zatvaramo datoteku
            sr.Close();
            Console.ReadKey();
        }
    }
}

